package com.example.data.repository

import com.example.data.api.GeminiService
import com.example.data.api.GeminiServiceImpl
import com.example.data.db.ChatDao
import com.example.data.model.ChatMessage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch

class ChatRepository(
    private val chatDao: ChatDao,
    private val geminiService: GeminiService = GeminiServiceImpl()
) {
    val allMessages: Flow<List<ChatMessage>> = chatDao.getAllMessages()

    suspend fun sendMessage(
        prompt: String,
        history: List<ChatMessage>,
        languagePreference: String
    ) {
        val trimmedPrompt = prompt.trim()
        if (trimmedPrompt.isEmpty()) return

        // 1. Insert user message into Room
        val userMessage = ChatMessage(
            text = trimmedPrompt,
            isUser = true,
            languageHint = languagePreference
        )
        chatDao.insertMessage(userMessage)

        // 2. Insert initial AI placeholder message
        val initialAiMessage = ChatMessage(
            text = "",
            isUser = false,
            languageHint = languagePreference,
            isError = false
        )
        val aiMessageId = chatDao.insertMessage(initialAiMessage)

        // 3. Stream response from Gemini API
        val accumulatedResponse = StringBuilder()

        try {
            geminiService.streamResponse(trimmedPrompt, history, languagePreference)
                .catch { error ->
                    val errorText = if (accumulatedResponse.isNotEmpty()) {
                        accumulatedResponse.append("\n\n[माफ़ कीजिये, कनेक्शन में त्रुटि हुई: ${error.localizedMessage}]").toString()
                    } else {
                        "माफ़ कीजिये, एक त्रुटि हुई: ${error.localizedMessage ?: "कृपया पुनः प्रयास करें।"}\n\nSorry, an error occurred. Please check your network and try again."
                    }
                    chatDao.updateMessageText(aiMessageId, errorText)
                }
                .collect { chunk ->
                    accumulatedResponse.append(chunk)
                    chatDao.updateMessageText(aiMessageId, accumulatedResponse.toString())
                }

            // If completely empty after streaming finished
            if (accumulatedResponse.isEmpty()) {
                val fallbackResponse = "नमस्ते! Mera AI आपके सवाल का उत्तर देने के लिए तैयार है।"
                chatDao.updateMessageText(aiMessageId, fallbackResponse)
            }
        } catch (e: Exception) {
            val errorText = "माफ़ कीजिये, एक त्रुटि हुई: ${e.localizedMessage ?: "कृपया पुनः प्रयास करें।"}\n\nSorry, an error occurred. Please check your connection."
            chatDao.updateMessageText(aiMessageId, errorText)
        }
    }

    suspend fun clearHistory() {
        chatDao.clearAllMessages()
    }

    suspend fun deleteMessage(id: Long) {
        chatDao.deleteMessage(id)
    }
}
