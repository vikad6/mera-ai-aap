package com.example.data.api

import android.util.Log
import com.example.BuildConfig
import com.example.data.model.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

interface GeminiService {
    /**
     * Stream generative content responses chunk-by-chunk from Gemini API.
     */
    fun streamResponse(
        prompt: String,
        history: List<ChatMessage> = emptyList(),
        languagePreference: String = "auto"
    ): Flow<String>

    /**
     * Single-shot generative content response from Gemini API.
     */
    suspend fun generateResponse(
        prompt: String,
        history: List<ChatMessage> = emptyList(),
        languagePreference: String = "auto"
    ): Result<String>
}

class GeminiServiceImpl(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
) : GeminiService {

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun getApiKey(): String {
        return BuildConfig.GEMINI_API_KEY
    }

    private fun buildSystemPrompt(languagePreference: String): String {
        return buildString {
            append("You are 'Mera AI' (मेरा AI), a friendly, helpful, and culturally aware AI chatbot designed to converse effortlessly in Hindi (हिन्दी), English, and Hinglish. ")
            append("Provide accurate, clear, and well-structured answers. ")
            when (languagePreference.lowercase()) {
                "hindi", "हिन्दी" -> append("Strictly answer in natural and clear Hindi (using Devanagari script). ")
                "english" -> append("Strictly answer in clear and fluent English. ")
                "hinglish" -> append("Answer in friendly Hinglish (Hindi written in Roman/English script) or mixed English-Hindi. ")
                else -> append("Match the language of the user's prompt (Hindi for Hindi, English for English, Hinglish for Hinglish). If ambiguous, provide a bilingual or easily readable answer. ")
            }
            append("Use clean formatting, bullet points, and brief paragraphs where helpful. Be warm, polite, and encouraging.")
        }
    }

    private fun createRequestBodyJson(
        prompt: String,
        history: List<ChatMessage>,
        languagePreference: String
    ): JSONObject {
        val contentsArray = JSONArray()

        // Include recent conversation context (up to 8 previous non-error messages)
        val contextHistory = history.filter { !it.isError }.takeLast(8)
        for (msg in contextHistory) {
            val item = JSONObject().apply {
                put("role", if (msg.isUser) "user" else "model")
                val parts = JSONArray().apply {
                    put(JSONObject().apply { put("text", msg.text) })
                }
                put("parts", parts)
            }
            contentsArray.put(item)
        }

        // Current prompt
        val currentMsg = JSONObject().apply {
            put("role", "user")
            val parts = JSONArray().apply {
                put(JSONObject().apply { put("text", prompt) })
            }
            put("parts", parts)
        }
        contentsArray.put(currentMsg)

        return JSONObject().apply {
            put("contents", contentsArray)
            put("systemInstruction", JSONObject().apply {
                val sysParts = JSONArray().apply {
                    put(JSONObject().apply { put("text", buildSystemPrompt(languagePreference)) })
                }
                put("parts", sysParts)
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("topP", 0.95)
                put("maxOutputTokens", 2048)
            })
        }
    }

    override fun streamResponse(
        prompt: String,
        history: List<ChatMessage>,
        languagePreference: String
    ): Flow<String> = flow {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            emit("नमस्ते! Mera AI में आपका स्वागत है।\n\nWelcome to Mera AI!\n\nNote: Please set your Gemini API key in the AI Studio Secrets panel to enable real-time AI responses.")
            return@flow
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse&key=$apiKey"
        val requestBodyJson = createRequestBodyJson(prompt, history, languagePreference)

        val request = Request.Builder()
            .url(url)
            .post(requestBodyJson.toString().toRequestBody(jsonMediaType))
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            val errorBody = response.body?.string().orEmpty()
            Log.e("GeminiService", "Stream API Error ${response.code}: $errorBody")
            val errorMsg = try {
                val errorJson = JSONObject(errorBody).optJSONObject("error")
                errorJson?.optString("message") ?: "HTTP ${response.code}"
            } catch (e: Exception) {
                "HTTP ${response.code}: ${response.message}"
            }
            response.close()
            throw Exception("Gemini API Error: $errorMsg")
        }

        val responseBody = response.body ?: throw Exception("Empty response body from Gemini API")
        
        responseBody.byteStream().use { inputStream ->
            BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).use { reader ->
                var line: String? = reader.readLine()
                while (line != null) {
                    if (line.startsWith("data: ")) {
                        val jsonData = line.substring(6).trim()
                        if (jsonData.isNotEmpty() && jsonData != "[DONE]") {
                            try {
                                val json = JSONObject(jsonData)
                                val candidates = json.optJSONArray("candidates")
                                if (candidates != null && candidates.length() > 0) {
                                    val candidate = candidates.getJSONObject(0)
                                    val content = candidate.optJSONObject("content")
                                    val parts = content?.optJSONArray("parts")
                                    if (parts != null && parts.length() > 0) {
                                        val textChunk = parts.getJSONObject(0).optString("text", "")
                                        if (textChunk.isNotEmpty()) {
                                            emit(textChunk)
                                        }
                                    }
                                }
                            } catch (e: Exception) {
                                Log.w("GeminiService", "Failed to parse SSE JSON chunk: $jsonData", e)
                            }
                        }
                    }
                    line = reader.readLine()
                }
            }
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun generateResponse(
        prompt: String,
        history: List<ChatMessage>,
        languagePreference: String
    ): Result<String> {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return Result.success(
                "नमस्ते! Mera AI में आपका स्वागत है।\n\n" +
                "Welcome to Mera AI! I am ready to answer your questions in Hindi and English.\n\n" +
                "Note: Please configure your Gemini API key in the AI Studio Secrets panel."
            )
        }

        return try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
            val requestBodyJson = createRequestBodyJson(prompt, history, languagePreference)

            val request = Request.Builder()
                .url(url)
                .post(requestBodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    Log.e("GeminiService", "API Error ${response.code}: $bodyString")
                    val errorMsg = try {
                        val errorJson = JSONObject(bodyString).optJSONObject("error")
                        errorJson?.optString("message") ?: "HTTP ${response.code}"
                    } catch (e: Exception) {
                        "HTTP ${response.code}: ${response.message}"
                    }
                    return Result.failure(Exception("Gemini API Error: $errorMsg"))
                }

                val json = JSONObject(bodyString)
                val candidates = json.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        val text = parts.getJSONObject(0).optString("text", "")
                        return Result.success(text.trim())
                    }
                }
                Result.failure(Exception("Empty response from AI"))
            }
        } catch (e: Exception) {
            Log.e("GeminiService", "generateResponse failed", e)
            Result.failure(e)
        }
    }
}
