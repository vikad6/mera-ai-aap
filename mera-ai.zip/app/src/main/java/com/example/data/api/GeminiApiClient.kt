package com.example.data.api

import android.util.Log
import com.example.BuildConfig
import com.example.data.model.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun generateResponse(
        prompt: String,
        history: List<ChatMessage>,
        languagePreference: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // Provide a friendly bilingual message if API key is not yet set in AI Studio Secrets
            return@withContext Result.success(
                "नमस्ते! Mera AI में आपका स्वागत है।\n\n" +
                "Welcome to Mera AI! I am ready to answer your questions in Hindi and English.\n\n" +
                "Note: To enable live AI generation, please ensure your Gemini API key is configured in the AI Studio Secrets panel."
            )
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"

            val systemPrompt = buildString {
                append("You are 'Mera AI' (मेरा AI), a friendly, helpful, and culturally aware AI chatbot designed to converse effortlessly in Hindi (हिन्दी), English, and Hinglish. ")
                append("Provide accurate, clear, and structured answers. ")
                when (languagePreference.lowercase()) {
                    "hindi", "हिन्दी" -> append("Strictly answer in natural and clear Hindi (using Devanagari script). ")
                    "english" -> append("Strictly answer in clear and fluent English. ")
                    "hinglish" -> append("Answer in friendly Hinglish (Hindi written in Roman/English script) or mixed English-Hindi. ")
                    else -> append("Match the language of the user's prompt (Hindi for Hindi, English for English, Hinglish for Hinglish). If ambiguous, provide a bilingual or easily readable answer. ")
                }
                append("Use clean formatting, bullet points, and brief paragraphs where helpful. Be warm, polite, and encouraging.")
            }

            val contentsArray = JSONArray()

            // Include recent conversation context (up to 8 previous non-error messages)
            val contextHistory = history.filter { !it.isError }.takeLast(8)
            for (msg in contextHistory) {
                val item = JSONObject().apply {
                    put("role", if (msg.isUser) "user" else "model")
                    val parts = JSONArray().apply {
                        put(JSONObject().apply { put("text", msg.text) })
                    }
                    put("parts", parts)
                }
                contentsArray.put(item)
            }

            // Append current prompt
            val currentMsg = JSONObject().apply {
                put("role", "user")
                val parts = JSONArray().apply {
                    put(JSONObject().apply { put("text", prompt) })
                }
                put("parts", parts)
            }
            contentsArray.put(currentMsg)

            val requestBodyJson = JSONObject().apply {
                put("contents", contentsArray)
                put("systemInstruction", JSONObject().apply {
                    val sysParts = JSONArray().apply {
                        put(JSONObject().apply { put("text", systemPrompt) })
                    }
                    put("parts", sysParts)
                })
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.7)
                    put("topP", 0.95)
                    put("maxOutputTokens", 1500)
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(requestBodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    Log.e("GeminiApiClient", "API Error ${response.code}: $responseBody")
                    val errorMessage = try {
                        val errorJson = JSONObject(responseBody).optJSONObject("error")
                        errorJson?.optString("message") ?: "Error ${response.code}"
                    } catch (e: Exception) {
                        "Error ${response.code}: ${response.message}"
                    }
                    return@withContext Result.failure(Exception("Gemini API Error: $errorMessage"))
                }

                val json = JSONObject(responseBody)
                val candidates = json.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        val text = parts.getJSONObject(0).optString("text", "")
                        return@withContext Result.success(text.trim())
                    }
                }
                Result.failure(Exception("Empty response from AI / AI से खाली उत्तर प्राप्त हुआ"))
            }
        } catch (e: Exception) {
            Log.e("GeminiApiClient", "Call failed", e)
            Result.failure(e)
        }
    }
}
