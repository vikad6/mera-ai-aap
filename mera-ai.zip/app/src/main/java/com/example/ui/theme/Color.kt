package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Colors - Vibrant Sapphire / Indigo
val PrimaryLight = Color(0xFF1E40AF)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFDBEAFE)
val OnPrimaryContainerLight = Color(0xFF1E3A8A)

val PrimaryDark = Color(0xFF93C5FD)
val OnPrimaryDark = Color(0xFF172554)
val PrimaryContainerDark = Color(0xFF1E3A8A)
val OnPrimaryContainerDark = Color(0xFFDBEAFE)

// Secondary Colors - Warm Saffron / Amber
val SecondaryLight = Color(0xFFC2410C)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFFFEDD5)
val OnSecondaryContainerLight = Color(0xFF7C2D12)

val SecondaryDark = Color(0xFFFDBA74)
val OnSecondaryDark = Color(0xFF431407)
val SecondaryContainerDark = Color(0xFF7C2D12)
val OnSecondaryContainerDark = Color(0xFFFFEDD5)

// Tertiary Colors - Mint / Emerald
val TertiaryLight = Color(0xFF047857)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFD1FAE5)
val OnTertiaryContainerLight = Color(0xFF064E3B)

val TertiaryDark = Color(0xFF6EE7B7)
val OnTertiaryDark = Color(0xFF022C22)
val TertiaryContainerDark = Color(0xFF064E3B)
val OnTertiaryContainerDark = Color(0xFFD1FAE5)

// Background & Surface
val BackgroundLight = Color(0xFFF8FAFC)
val OnBackgroundLight = Color(0xFF0F172A)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF0F172A)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceVariantLight = Color(0xFF475569)

val BackgroundDark = Color(0xFF0B0F19)
val OnBackgroundDark = Color(0xFFF1F5F9)
val SurfaceDark = Color(0xFF111827)
val OnSurfaceDark = Color(0xFFF1F5F9)
val SurfaceVariantDark = Color(0xFF1E293B)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
