package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.ChatMessage
import com.example.data.repository.ChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatUiState(
    val inputText: String = "",
    val isLoading: Boolean = false,
    val selectedLanguage: String = "Auto",
    val snackbarMessage: String? = null
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: ChatRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = ChatRepository(database.chatDao())
    }

    val messages: StateFlow<List<ChatMessage>> = repository.allMessages.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    fun onInputTextChanged(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun onLanguageSelected(language: String) {
        _uiState.update { it.copy(selectedLanguage = language) }
    }

    fun sendMessage(customPrompt: String? = null) {
        val textToSend = (customPrompt ?: _uiState.value.inputText).trim()
        if (textToSend.isBlank() || _uiState.value.isLoading) return

        // Clear input text immediately if using the input box
        if (customPrompt == null) {
            _uiState.update { it.copy(inputText = "", isLoading = true) }
        } else {
            _uiState.update { it.copy(isLoading = true) }
        }

        viewModelScope.launch {
            try {
                val currentHistory = messages.value
                val langPref = _uiState.value.selectedLanguage
                repository.sendMessage(textToSend, currentHistory, langPref)
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(snackbarMessage = "Failed to send: ${e.localizedMessage}")
                }
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            repository.clearHistory()
            _uiState.update { it.copy(snackbarMessage = "Chat cleared / बातचीत साफ़ कर दी गई") }
        }
    }

    fun deleteMessage(id: Long) {
        viewModelScope.launch {
            repository.deleteMessage(id)
        }
    }

    fun dismissSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
